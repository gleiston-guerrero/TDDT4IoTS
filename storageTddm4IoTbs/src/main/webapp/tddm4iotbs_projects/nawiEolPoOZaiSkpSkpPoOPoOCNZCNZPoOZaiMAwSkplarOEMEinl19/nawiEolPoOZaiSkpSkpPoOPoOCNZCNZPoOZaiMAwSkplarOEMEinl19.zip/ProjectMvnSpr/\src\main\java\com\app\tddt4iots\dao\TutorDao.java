package com.app.tddt4iots.dao;
 
 import com.app.tddt4iots.entities.Tutor;
 import org.springframework.data.jpa.repository.JpaRepository;
 
 public interface TutorDao extends JpaRepository<Tutor, Long> {
 }
