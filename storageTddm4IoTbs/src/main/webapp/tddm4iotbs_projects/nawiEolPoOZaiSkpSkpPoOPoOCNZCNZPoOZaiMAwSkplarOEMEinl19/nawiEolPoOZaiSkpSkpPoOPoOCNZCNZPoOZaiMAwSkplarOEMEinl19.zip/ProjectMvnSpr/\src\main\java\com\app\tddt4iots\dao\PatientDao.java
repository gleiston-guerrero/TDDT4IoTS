package com.app.tddt4iots.dao;
 
 import com.app.tddt4iots.entities.Patient;
 import org.springframework.data.jpa.repository.JpaRepository;
 
 public interface PatientDao extends JpaRepository<Patient, Long> {
 }
