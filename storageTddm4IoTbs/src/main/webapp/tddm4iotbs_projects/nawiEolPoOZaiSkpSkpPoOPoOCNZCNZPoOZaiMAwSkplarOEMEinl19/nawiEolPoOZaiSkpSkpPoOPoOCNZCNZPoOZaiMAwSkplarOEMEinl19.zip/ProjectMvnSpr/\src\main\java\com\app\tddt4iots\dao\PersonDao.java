package com.app.tddt4iots.dao;
 
 import com.app.tddt4iots.entities.Person;
 import org.springframework.data.jpa.repository.JpaRepository;
 
 public interface PersonDao extends JpaRepository<Person, Long> {
 }
