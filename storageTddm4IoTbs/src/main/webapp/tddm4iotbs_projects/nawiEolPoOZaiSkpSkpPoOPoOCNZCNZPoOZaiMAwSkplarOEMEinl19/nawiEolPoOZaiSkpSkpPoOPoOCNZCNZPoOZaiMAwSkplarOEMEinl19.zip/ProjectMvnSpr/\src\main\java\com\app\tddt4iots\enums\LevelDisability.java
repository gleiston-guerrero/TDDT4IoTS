package com.app.tddt4iots.enums;
 
public enum LevelDisability { 
	LevelOne,LevelTwo,LevelTree	
} 
