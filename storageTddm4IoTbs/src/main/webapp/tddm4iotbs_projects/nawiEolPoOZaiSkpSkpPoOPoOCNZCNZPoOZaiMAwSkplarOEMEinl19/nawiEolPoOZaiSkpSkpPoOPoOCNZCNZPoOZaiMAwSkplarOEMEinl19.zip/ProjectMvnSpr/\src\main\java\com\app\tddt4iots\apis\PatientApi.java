package com.app.tddt4iots.apis;

import com.app.tddt4iots.entities.Patient;
import com.app.tddt4iots.dao.PatientDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/patient")
public class PatientApi {

    @Autowired
    private PatientDao patientDAO;

    @GetMapping
    public ResponseEntity<List<Patient>> getPatient() {
        List<Patient> listPatient = patientDAO.findAll();
        return ResponseEntity.ok(listPatient);
    }

    @PostMapping
    public ResponseEntity<Patient> insertPatient(@RequestBody Patient patient) {
        Patient newPatient = patientDAO.save(patient);
        return ResponseEntity.ok(newPatient);
    }

    @PutMapping
    public ResponseEntity<Patient> updatePatient(@RequestBody Patient patient) {
        Patient upPatient = patientDAO.save(patient);
        if (upPatient != null) {
            return ResponseEntity.ok(upPatient);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping(value = "{id}")
    public ResponseEntity<Patient> deletePersons(@PathVariable("id") Long id) {
        patientDAO.deleteById(id);
        return ResponseEntity.ok(null);
    }

}
