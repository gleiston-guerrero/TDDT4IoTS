package com.app.tddt4iots.apis;

import com.app.tddt4iots.entities.Tutor;
import com.app.tddt4iots.dao.TutorDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tutor")
public class TutorApi {

    @Autowired
    private TutorDao tutorDAO;

    @GetMapping
    public ResponseEntity<List<Tutor>> getTutor() {
        List<Tutor> listTutor = tutorDAO.findAll();
        return ResponseEntity.ok(listTutor);
    }

    @PostMapping
    public ResponseEntity<Tutor> insertTutor(@RequestBody Tutor tutor) {
        Tutor newTutor = tutorDAO.save(tutor);
        return ResponseEntity.ok(newTutor);
    }

    @PutMapping
    public ResponseEntity<Tutor> updateTutor(@RequestBody Tutor tutor) {
        Tutor upTutor = tutorDAO.save(tutor);
        if (upTutor != null) {
            return ResponseEntity.ok(upTutor);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping(value = "{id}")
    public ResponseEntity<Tutor> deletePersons(@PathVariable("id") Long id) {
        tutorDAO.deleteById(id);
        return ResponseEntity.ok(null);
    }

}
