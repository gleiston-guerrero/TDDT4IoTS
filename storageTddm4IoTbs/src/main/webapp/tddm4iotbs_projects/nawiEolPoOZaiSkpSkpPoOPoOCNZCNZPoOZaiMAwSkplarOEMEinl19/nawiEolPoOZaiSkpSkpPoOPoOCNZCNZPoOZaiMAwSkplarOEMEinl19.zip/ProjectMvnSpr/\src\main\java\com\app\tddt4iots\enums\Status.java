package com.app.tddt4iots.enums;
 
public enum Status { 
	Disabled,Enabled	
} 
