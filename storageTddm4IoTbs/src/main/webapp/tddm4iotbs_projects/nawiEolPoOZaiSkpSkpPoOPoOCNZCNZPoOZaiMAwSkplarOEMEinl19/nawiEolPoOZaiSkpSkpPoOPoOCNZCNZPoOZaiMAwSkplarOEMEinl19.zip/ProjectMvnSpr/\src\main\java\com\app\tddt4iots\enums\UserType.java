package com.app.tddt4iots.enums;
 
public enum UserType { 
	Tutor,Patient,Admin	
} 
