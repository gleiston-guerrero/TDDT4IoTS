package com.app.tddt4iots;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NawiEolPoOcnzmAwYUoSkpYUoYUoPoOSkprZbtjyPoOeeMhnHdUDs19Application {

	public static void main(String[] args) {
		SpringApplication.run(NawiEolPoOcnzmAwYUoSkpYUoYUoPoOSkprZbtjyPoOeeMhnHdUDs19Application.class, args);
	}

}
