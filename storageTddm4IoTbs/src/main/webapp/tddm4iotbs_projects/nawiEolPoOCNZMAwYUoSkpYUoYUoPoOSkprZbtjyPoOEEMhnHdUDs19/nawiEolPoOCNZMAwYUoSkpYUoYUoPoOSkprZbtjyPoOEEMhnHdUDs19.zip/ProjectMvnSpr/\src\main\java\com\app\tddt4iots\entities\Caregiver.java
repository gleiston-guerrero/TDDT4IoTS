package com.app.tddt4iots.entities;
 
import com.app.tddt4iots.enums.*;
import lombok.Data;
 import lombok.NoArgsConstructor;
 
import javax.persistence.*;
 import java.util.ArrayList;
 
@Entity
 @Table(name = "Caregiver")
 @Data
 @NoArgsConstructor
 public class Caregiver {
     
    @Id
     @GeneratedValue(strategy = GenerationType.AUTO)
     private Long firstName;
     
    @Column(name = "lastName", nullable = false, unique = false, length = 30) 
    private String lastName; 
 
    @Column(name = "dateOfBirth", nullable = false, unique = false) 
    private String dateOfBirth; 
 
    @Column(name = "gender", nullable = false, unique = false) 
    private String gender; 
 
    @Column(name = "phone", nullable = false, unique = false, length = 30) 
    private String phone; 
 
    @Column(name = "email", nullable = false, unique = false, length = 30) 
    private String email; 
 
    @Column(name = "password", nullable = false, unique = false, length = 30) 
    private String password; 
 
    @Column(name = "status", nullable = false, unique = false) 
    private String status; 
 
   @JoinColumn(name = "firstName", referencedColumnName = "firstName") 
   @ManyToOne 
    private ArrayList<AssistedPerson> assisted person; 
 
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.firstName == null ) ? 0 : this.firstName.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Caregiver)) {
            return false;
        }
        Caregiver other = (Caregiver) object;
        if ((this.firstName == null && other.firstName != null) || (this.firstName != null && !this.firstName.equals(other.firstName))) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return "com.app.tddt4iots.entities.Caregiver[ firstName=" + firstName + " ]";
    }
}    
