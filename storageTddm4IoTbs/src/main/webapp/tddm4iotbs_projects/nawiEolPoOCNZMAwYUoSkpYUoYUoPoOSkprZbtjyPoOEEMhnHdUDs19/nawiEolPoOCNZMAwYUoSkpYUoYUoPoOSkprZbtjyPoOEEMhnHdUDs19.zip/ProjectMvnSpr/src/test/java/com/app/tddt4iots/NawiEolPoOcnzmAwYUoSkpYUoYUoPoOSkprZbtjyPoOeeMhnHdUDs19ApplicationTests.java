package com.app.tddt4iots;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NawiEolPoOcnzmAwYUoSkpYUoYUoPoOSkprZbtjyPoOeeMhnHdUDs19ApplicationTests {

	@Test
	void contextLoads() {
	}

}
